package com.example.movietheatre;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    GridView CategoryGrid;
    ArrayAdapter<String> CategoriesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MovieDBHelper MyDBHelper = new MovieDBHelper(this);
        CategoriesAdapter = new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1);
        Cursor cursor = MyDBHelper.FetchAllCategories();
        if(cursor.getCount() != 0){
            while(!cursor.isAfterLast()){
                CategoriesAdapter.add(cursor.getString(1));
                cursor.moveToNext();
            }};
        CategoryGrid = (GridView)findViewById(R.id.CategoryGrid);
        CategoryGrid.setAdapter(CategoriesAdapter);
        CategoryGrid.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView v = (TextView) view;
                String SelectedCategory = v.getText().toString();
                Cursor cursor = MyDBHelper.RetrieveCategoryID(SelectedCategory);
                Intent intent = new Intent(MainActivity.this, MoviesDisplay.class);
                intent.putExtra("CatID",cursor.getInt(0));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.AddCategory:
                Intent intent = new Intent(MainActivity.this, CategoryAdd.class);
                startActivity(intent);
                return true;
        }
        return false;
    }
}