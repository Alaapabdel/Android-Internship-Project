package com.example.movietheatre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

public class MoviesDisplay extends AppCompatActivity {

    GridView MovieGrid;
    ArrayAdapter<String> MovieAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        MovieDBHelper MyDBHelper = new MovieDBHelper(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies_display);
        MovieAdapter = new ArrayAdapter<String>(MoviesDisplay.this,android.R.layout.simple_list_item_1);
        Cursor cursor = MyDBHelper.FetchAllMovies(getIntent().getExtras().getInt("CatID"));
        if(cursor.getCount() != 0){
            while(!cursor.isAfterLast()){
                MovieAdapter.add(cursor.getString(0));
                cursor.moveToNext();
            }};
        MovieGrid = (GridView)findViewById(R.id.MovieDisplayGrid);
        MovieGrid.setAdapter(MovieAdapter);
        MovieGrid.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView v = (TextView) view;
                String SelectedMovie = v.getText().toString();
                Intent intent = new Intent(MoviesDisplay.this, MovieDescription.class);
                intent.putExtra("CatID", getIntent().getExtras().getInt("CatID"));
                intent.putExtra("MovName",SelectedMovie);
                startActivity(intent);
            }
        });
        Button MovieAddButton = (Button) findViewById(R.id.MovieAddButton);
        MovieAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MoviesDisplay.this, AddMovie.class);
                startActivity(intent);
            }
        });
        MovieGrid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           int position, long arg3) {
                TextView v = (TextView) arg1;
                String SelectedMovie = v.getText().toString();
                MyDBHelper.DeleteMovie(getIntent().getExtras().getInt("CatID"),SelectedMovie);
                Intent intent = new Intent(MoviesDisplay.this, AddMovie.class);
                startActivity(intent);
                return true;
            }
        });
    }
}