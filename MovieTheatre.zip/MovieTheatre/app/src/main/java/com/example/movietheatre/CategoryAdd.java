package com.example.movietheatre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CategoryAdd extends AppCompatActivity {

    Button AddButton;
    EditText CategoryName;
    EditText CategoryID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_add);
        CategoryName = (EditText) findViewById(R.id.CategoryName);
        CategoryID = (EditText) findViewById(R.id.CategoryID);
        AddButton = (Button) findViewById(R.id.AddButton);
        MovieDBHelper MyDBHelper = new MovieDBHelper(this);
        AddButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                MyDBHelper.AddCategory( Integer.parseInt(CategoryID.getText().toString()), CategoryName.getText().toString());
                Intent intend = new Intent(CategoryAdd.this, MainActivity.class);
                startActivity(intend);
            }
        });
    }
}