package com.example.movietheatre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddMovie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie);
        EditText MovieName = (EditText) findViewById(R.id.AddMovieMovName);
        EditText MovieID = (EditText) findViewById(R.id.AddMovieMovID);
        EditText MovieDescription = (EditText) findViewById(R.id.AddMovieMovDesc);
        EditText MovieRate = (EditText) findViewById(R.id.AddMovieMovRate);
        EditText CategoryID = (EditText) findViewById(R.id.AddMovieCatID);
        MovieDBHelper MyDBHelper = new MovieDBHelper(this);
        Button AddMovieButton = (Button) findViewById(R.id.AddMovieButton);
        AddMovieButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDBHelper.AddMovie(Integer.parseInt(MovieID.getText().toString()), MovieName.getText().toString(), MovieDescription.getText().toString(), MovieRate.getText().toString(), Integer.parseInt(CategoryID.getText().toString()));
                Intent intent = new Intent(AddMovie.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
}