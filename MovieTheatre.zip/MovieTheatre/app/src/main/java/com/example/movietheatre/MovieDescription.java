package com.example.movietheatre;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MovieDescription extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_description);
        MovieDBHelper MyDBHelper = new MovieDBHelper(this);
        TextView MovieName = (TextView) findViewById(R.id.MovieName);
        MovieName.setText(getIntent().getExtras().getString("MovName"));
        EditText MovieNameDisplay = (EditText) findViewById(R.id.MovieNameDisplay);
        TextView MovieIDDisplay = (TextView) findViewById(R.id.MovieIDDisplay);
        EditText MovieDescriptionDisplay = (EditText) findViewById(R.id.MovieDescriptionDisplay);
        EditText MovieRateDisplay = (EditText) findViewById(R.id.MovieRateDisplay);
        EditText CategoryIDDisplay = (EditText) findViewById(R.id.MovieCatIDDisplay);
        Cursor cursor = MyDBHelper.RetrieveMovieDescription(getIntent().getExtras().getInt("CatID"),getIntent().getExtras().getString("MovName"));
        if (cursor.getCount() != 0) {
            while (!cursor.isAfterLast()) {
                MovieIDDisplay.setText(String.valueOf(cursor.getInt(0)));
                MovieNameDisplay.setText(cursor.getString(1));
                MovieDescriptionDisplay.setText(cursor.getString(2));
                MovieRateDisplay.setText(cursor.getString(3));
                CategoryIDDisplay.setText(String.valueOf(cursor.getInt(4)));
                cursor.moveToNext();
            }
        }
        Button SaveButton = (Button) findViewById(R.id.SaveButton);
        SaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDBHelper.UpdateMovie(Integer.parseInt(MovieIDDisplay.getText().toString()),MovieNameDisplay.getText().toString(),MovieDescriptionDisplay.getText().toString(),MovieRateDisplay.getText().toString(),Integer.parseInt(CategoryIDDisplay.getText().toString()));
                Intent intent = new Intent(MovieDescription.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}