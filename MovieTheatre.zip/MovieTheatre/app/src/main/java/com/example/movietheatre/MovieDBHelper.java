package com.example.movietheatre;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.Set;

public class MovieDBHelper extends SQLiteOpenHelper{

    private static String DatabaseName = "MovieDatabase";
    SQLiteDatabase MovieDatabase;
    public MovieDBHelper(Context context) {
        super(context, DatabaseName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Categories(CatID integer primary key, CatName string not null)");
        db.execSQL("create table Movies(MovID integer primary key, MovName string not null, MovDesc string not null, MovRate string not null, CatID integer not null)");

        //Categories
        ContentValues insertValues = new ContentValues();
        insertValues.put("CatID", 80877);
        insertValues.put("CatName", "Action");
        db.insert("Categories", null, insertValues);
        insertValues = new ContentValues();
        insertValues.put("CatID", 21281);
        insertValues.put("CatName", "Comedy");
        db.insert("Categories", null, insertValues);

        //Movies - Category Action
        insertValues = new ContentValues();
        insertValues.put("MovID", 132548);
        insertValues.put("MovName", "SPIDER-MAN 2");
        insertValues.put("MovDesc", "Boasting an entertaining villain and deeper emotional focus, this is a nimble sequel that improves upon the original");
        insertValues.put("MovRate", "4.0");
        insertValues.put("CatID", 80877);
        db.insert("Movies", null, insertValues);
        insertValues = new ContentValues();
        insertValues.put("MovID", 655881);
        insertValues.put("MovName", "BATTLE ROYALE");
        insertValues.put("MovDesc", "Battle Royale is a controversial and violent parable of adolescence, heightening teenage melodrama with life-or-death stakes.");
        insertValues.put("MovRate", "3.5");
        insertValues.put("CatID", 80877);
        db.insert("Movies", null, insertValues);
        insertValues = new ContentValues();
        insertValues.put("MovID", 655882);
        insertValues.put("MovName", "ESCAPE FROM NEW YORK");
        insertValues.put("MovDesc", "Featuring an atmospherically grimy futuristic metropolis, Escape from New York is a strange, entertaining jumble of thrilling action and oddball weirdness.");
        insertValues.put("MovRate", "4.2");
        insertValues.put("CatID", 80877);
        db.insert("Movies", null, insertValues);
        insertValues = new ContentValues();
        insertValues.put("MovID", 655883);
        insertValues.put("MovName", "IRON MONKEY");
        insertValues.put("MovDesc", "Iron Monkey may not have the poetic lyricism of Crouching Tiger, it makes up for it in fun and energy.");
        insertValues.put("MovRate", "3.8");
        insertValues.put("CatID", 80877);
        db.insert("Movies", null, insertValues);

        //Movies - Category Comedy
        insertValues = new ContentValues();
        insertValues.put("MovID", 655880);
        insertValues.put("MovName", "Juno");
        insertValues.put("MovDesc", "The chemical equation of writer Diablo Cody plus director Jason Reitman explodes onscreen with this non-traditional family comedy showcasing Cody’s edgy contemporary dialogue.");
        insertValues.put("MovRate", "4.3");
        insertValues.put("CatID", 21281);
        db.insert("Movies", null, insertValues);
        insertValues = new ContentValues();
        insertValues.put("MovID", 132570);
        insertValues.put("MovName", "Shaun of the Dead");
        insertValues.put("MovDesc", "This acerbic action comedy introduced a winning combo: sparring buddies Simon Pegg and Nick Frost and master of style Edgar Wright, who dreamed up the script with Pegg.");
        insertValues.put("MovRate", "4.1");
        insertValues.put("CatID", 21281);
        db.insert("Movies", null, insertValues);
        insertValues = new ContentValues();
        insertValues.put("MovID", 132574);
        insertValues.put("MovName", "Old School");
        insertValues.put("MovDesc", "You’re my boy, Blue! Say what you will about the Frat Pack films that followed it, but “Old School” still gets a passing grade.");
        insertValues.put("MovRate", "2.4");
        insertValues.put("CatID", 21281);
        db.insert("Movies", null, insertValues);
        insertValues = new ContentValues();
        insertValues.put("MovID", 164438);
        insertValues.put("MovName", "Trainwreck");
        insertValues.put("MovDesc", "Producer Judd Apatow steered breakout standup comic Amy Schumer to her smash big-screen debut ($141 million worldwide) by helping her to write a recognizably real woman to play — accessible, honest, emotional — within the genre confines of a mainstream romantic comedy.");
        insertValues.put("MovRate", "3.9");
        insertValues.put("CatID", 21281);
        db.insert("Movies", null, insertValues);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists Categories");
        db.execSQL("drop table if exists Movies");
        onCreate(db);
    }

    public void AddCategory(int CatID, String CatName){
        MovieDatabase = getWritableDatabase();
        ContentValues row = new ContentValues();
        row.put("CatID",CatID);
        row.put("CatName",CatName);
        MovieDatabase.insert("Categories",null,row);
        MovieDatabase.close();
    }

    public Cursor FetchAllCategories(){
        MovieDatabase = getReadableDatabase();
        Cursor cursor = MovieDatabase.rawQuery("Select * From Categories",null);
        cursor.moveToFirst();
        MovieDatabase.close();
        return cursor;
    }

    public Cursor FetchAllMovies(int CatID){
        MovieDatabase = getReadableDatabase();
        String[] Arg = {String.valueOf(CatID)};
        Cursor cursor = MovieDatabase.rawQuery("Select MovName from Movies where CatID = ?", Arg);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public Cursor RetrieveCategoryID(String CatName) {
        MovieDatabase = getReadableDatabase();
        String[] Arg = {String.valueOf(CatName)};
        Cursor cursor = MovieDatabase.rawQuery("select CatID from Categories where CatName = ?", Arg);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public Cursor RetrieveMovieDescription(int CatID, String MovName) {
        MovieDatabase = getReadableDatabase();
        String[] Arg = {String.valueOf(CatID), String.valueOf(MovName)};
        Cursor cursor = MovieDatabase.rawQuery("select * from Movies where CatID = ? and MovName = ?", Arg);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
        }
        return cursor;
    }

    public void AddMovie(int MovID, String MovName, String MovDesc, String MovRate, int CatID){
        MovieDatabase = getWritableDatabase();
        ContentValues row = new ContentValues();
        row.put("MovID",MovID);
        row.put("MovName",MovName);
        row.put("MovDesc",MovDesc);
        row.put("MovRate",MovRate);
        row.put("CatID",CatID);
        MovieDatabase.insert("Movies",null,row);
        MovieDatabase.close();
    }

    public void DeleteMovie(int CatID, String MovName){
        MovieDatabase = getWritableDatabase();
        MovieDatabase.delete("Movies","MovName = '"+MovName+"'"+"AND CatID ="+String.valueOf(CatID),null);
        MovieDatabase.close();
    }

    public void UpdateMovie(int MovID, String MovName, String MovDesc, String MovRate, int CatID){
        MovieDatabase = getWritableDatabase();
        ContentValues row = new ContentValues();
        row.put("MovName",MovName);
        row.put("MovDesc",MovDesc);
        row.put("MovRate",MovRate);
        row.put("CatID",CatID);
        MovieDatabase.update("Movies",row,"MovID = ?", new String[]{String.valueOf(MovID)});
        MovieDatabase.close();
    }
}
